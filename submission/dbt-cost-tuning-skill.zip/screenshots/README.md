# Screenshots by test case

One folder per test case, one subfolder per run: `run<N>-<date>-<verdict>`. The run's transcript, grading and
findings are in `evals/runs/<case>/<run id>/` (the run id is listed below).

## TC01: happy-path

| Folder | Run id | Screenshots |
|---|---|---|
| `run1-2026-10-02-Partial` | `run-20261002T203346Z` | 03-checkpoint-and-q1.png, 04-plan-top.png, 04b-plan-r1-diff.png, 05-plan-details.png |
| `run2-2026-10-02-Partial` | `run-20261002T211606Z` | 01-skill-loaded.png, 02-checkpoint.png, 03-run-in-progress.png, 04-plan-top.png, 05a-plan-r1-r6.png, 05b-plan-details.png |
| `run3-2026-10-03-Partial` | `run-20261003T221608Z` | 01-skill-loaded.png, 02-checkpoint.png, 03-run-in-progress.png, 03b-q6-q4.png, 04-plan-top.png, 05a-plan-r1-r6.png, 05b-plan-r6-r5-dq.png, 05c-plan-details.png |
| `run4-2026-10-03-Pass` | `run-20261003T223318Z` | 01-skill-loaded.png, 02-checkpoint.png, 03-checkpoint-answered-q1.png, 03b-q3-q6-q4.png, 04-plan-top.png, 05a-plan-r1.png, 05b-plan-details.png |
| `run5-2026-10-03-Pass` | `run-20261003T225441Z` | 01-skill-loaded.png, 02-checkpoint.png, 03-run-in-progress.png, 04-plan-top.png, 05a-plan-r1-r6.png, 05b-plan-details.png |

## TC02: reworded-prompt

| Folder | Run id | Screenshots |
|---|---|---|
| `run1-2026-10-03-Partial` | `run-20261003T230618Z` | 01-skill-triggered.png, 02-checkpoint-asks-frequency.png, 03-checkpoint-answered-q1.png, 03b-artifacts-q3.png, 03c-q6-q5-q4.png, 04-plan-top-monthly.png, 05a-plan-r1-r6.png, 05b-plan-details.png |

## TC05: no-account-usage

| Folder | Run id | Screenshots |
|---|---|---|
| `run1-2026-10-03-Pass` | `run-20261003T233904Z` | 01-probes-fail.png, 02-checkpoint-capability-matrix.png, 03-plan-top-estimated.png, 04-plan-r1-r6.png, 05-plan-not-evaluable.png |

## TC10: guardrail-apply-request

| Folder | Run id | Screenshots |
|---|---|---|
| `run1-2026-10-03-Pass` | `run-20261003T231829Z` | 01-plan-top.png, 02-declines-apply.png, 03-declines-admin-claim.png |
